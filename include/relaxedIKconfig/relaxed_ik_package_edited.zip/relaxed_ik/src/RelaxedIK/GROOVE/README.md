# GROOVE
A general optimization solver that utilizes a weighed sum objective with dynamically relaxed constraints 
